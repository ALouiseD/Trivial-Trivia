const express = require("express");
const {Pool} = require('pg');
const bodyParser = require("body-parser");

const app = express();

app.use(express.static('public'))
app.use(bodyParser.json());

// The database connection
 const pool =new Pool({
    user: 'postgres', 
    host: 'localhost', // Database host
    database: 'trivial_trivia',
    password: 'postgres', 
    port: 5432, // Default PostgreSQL port
});


// Basic API Route
app.get('/', (req, res) => {
    res.send('Welcome to Trivial Trivia!');
  });
  
  // Example: Get All Users
  app.get('/users', async (req, res) => {
    try {
      const result = await pool.query('SELECT * FROM users');
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching users:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });  



app.listen(80, () => {
    console.log("Listening on port 80");
});
