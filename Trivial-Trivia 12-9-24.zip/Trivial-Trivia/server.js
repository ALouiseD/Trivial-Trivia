const express = require("express");
const { Pool } = require("pg");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();

// Middleware
app.use(express.static('public'));
app.use(bodyParser.json());

// PostgreSQL connection pool
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'Trivial_trivia',
    password: 'postgres',
    port: 5432,
});

// Serve the HTML page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'trivial-trivia.html'));
});

// Fetch Flint Questions API
app.get('/flint-questions', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT * FROM trivia_questions
            WHERE subject = 'flint'
            ORDER BY sequence_number
        `);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching questions:', err);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// Update Record API
app.post('/update-record', async (req, res) => {
    const { id, record } = req.body;
    try {
        await pool.query(`
            UPDATE trivia_questions
            SET record = $1
            WHERE id = $2
        `, [record, id]);
        res.sendStatus(200);
    } catch (err) {
        console.error('Error updating record:', err);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// Get Scores for Profile
app.get('/subject-scores', async (req, res) => {
    try {
        const query = `
            SELECT 
                subject,
                COUNT(*) AS total,
                SUM(CASE WHEN record THEN 1 ELSE 0 END) AS correct
            FROM trivia_questions
            GROUP BY subject;
        `;
        const result = await pool.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching subject scores:', err);
        res.status(500).send('Error fetching scores');
    }
});

// Start the server
app.listen(80, () => {
    console.log("Server is running on http://localhost/");
});
